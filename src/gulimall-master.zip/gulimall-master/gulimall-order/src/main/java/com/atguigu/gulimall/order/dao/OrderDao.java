package com.atguigu.gulimall.order.dao;

import com.atguigu.gulimall.order.entity.OrderEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 订单
 * 
 * @author haoze
 * @email ${email}
 * @date 2024-10-19 09:45:58
 */
@Mapper
public interface OrderDao extends BaseMapper<OrderEntity> {
	
}
