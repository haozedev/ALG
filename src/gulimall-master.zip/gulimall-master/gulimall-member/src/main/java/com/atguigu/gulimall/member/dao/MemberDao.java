package com.atguigu.gulimall.member.dao;

import com.atguigu.gulimall.member.entity.MemberEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 会员
 * 
 * @author haoze
 * @email ${email}
 * @date 2024-10-19 10:14:06
 */
@Mapper
public interface MemberDao extends BaseMapper<MemberEntity> {
	
}
