package com.atguigu.gulimall.coupon.dao;

import com.atguigu.gulimall.coupon.entity.CouponEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 优惠券信息
 * 
 * @author haoze
 * @email ${email}
 * @date 2024-10-19 09:05:05
 */
@Mapper
public interface CouponDao extends BaseMapper<CouponEntity> {
	
}
