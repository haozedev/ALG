/**
 * Copyright (c) 2016-2019 人人开源 All rights reserved.
 *
 * https://www.renren.io
 *
 * 版权所有，侵权必究！
 */

package com.atguigu.gulimall.product.interceptor;


import com.atguigu.gulimall.product.annotation.Login;
import com.atguigu.gulimall.product.exception.RRException;
import com.atguigu.gulimall.product.service.SysUserTokenService;
import com.atguigu.gulimall.product.utils.JwtUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 权限(Token)验证
 *
 * @author Mark sunlightcs@gmail.com
 */
@Component
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {
    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private SysUserTokenService sysUserTokenService;

    public static final String USER_KEY = "userId";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Login annotation;
//        if(handler instanceof HandlerMethod) {
//            annotation = ((HandlerMethod) handler).getMethodAnnotation(Login.class);
//        }else{
//            return true;
//        }
//
//        if(annotation == null){
//            return true;
//        }

        String header = "token";
        //获取用户凭证
        String token = request.getHeader(header);
        if(StringUtils.isBlank(token)){
            token = request.getParameter(header);
        }

        //凭证为空
        if(StringUtils.isBlank(token)){
            throw new RRException(header + "不能为空", HttpStatus.UNAUTHORIZED.value());
        }
        boolean tokenIsRight = sysUserTokenService.checkToken(token);
//        Claims claims = jwtUtils.getClaimByToken(token);
        if(!tokenIsRight){
            throw new RRException(header + "失效，请重新登录", HttpStatus.UNAUTHORIZED.value());
        }

        //设置userId到request里，后续根据userId，获取用户信息
//        request.setAttribute(USER_KEY, Long.parseLong(claims.getSubject()));

        return true;
    }
}
