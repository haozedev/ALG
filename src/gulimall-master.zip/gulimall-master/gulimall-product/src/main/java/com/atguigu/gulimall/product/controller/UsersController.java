package com.atguigu.gulimall.product.controller;

import com.atguigu.common.utils.PageUtils;
import com.atguigu.common.utils.R;
import com.atguigu.gulimall.product.entity.UserEntity;
import com.atguigu.gulimall.product.entity.UserForm;
import com.atguigu.gulimall.product.service.SysUserTokenService;
import com.atguigu.gulimall.product.service.UsersService;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;



/**
 * 用户表
 *
 * @author haoze
 * @email ${email}
 * @date 2025-05-27 09:35:21
 */
@RestController
@RequestMapping("product/users")
public class UsersController {
    @Autowired
    private UsersService usersService;

    @Autowired
    private SysUserTokenService sysUserTokenService;
    /**
     * 登录
     */
    @PostMapping("/sys/login")
    public Map<String, Object> login(@RequestBody UserForm form)throws IOException {
//        boolean captcha = usersService.validate(form.getUsername(), form.getPassword());
//        if(!captcha){
//            return R.error("验证码不正确");
//        }

        //用户信息
        UserEntity user = usersService.queryByUserName(form.getUsername());

        //账号不存在、密码错误
        String passwordAfterSalt = new Sha256Hash(form.getPassword(), user.getSalt()).toHex();
        if(user == null || !user.getPassword().equals(passwordAfterSalt)) {
            return R.error("账号或密码不正确");
        }

        //账号锁定
//        if(user.getStatus() == 0){
//            return R.error("账号已被锁定,请联系管理员");
//        }

        //生成token，并保存到数据库
        R r = sysUserTokenService.createToken(user.getUserId());
        return r;
    }
    @PostMapping("/register")
    public R register(@RequestBody UserForm form){

        UserEntity user = new UserEntity();
        //用户信息
        UserEntity user1 = usersService.queryByUserName(form.getUsername());
        if (user1==null){
            user.setMobile(form.getMobile());
            user.setUsername(form.getUsername());
            String salt = RandomStringUtils.randomAlphanumeric(20);
            user.setSalt(salt);
            user.setPassword(new Sha256Hash(form.getPassword(), salt).toHex());
            user.setCreateTime(new Date());
            usersService.save(user);
            return R.ok();
        }else {
            return R.error("用户名已存在或者该用户已注册");
        }

    }

    /**
     * 列表
     */
    @RequestMapping("/list")
    ////@RequiresPermissions("product:users:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = usersService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{userId}")
    ////@RequiresPermissions("product:users:info")
    public R info(@PathVariable("userId") Integer userId){
		UserEntity users = usersService.getById(userId);

        return R.ok().put("users", users);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    ////@RequiresPermissions("product:users:save")
    public R save(@RequestBody UserEntity users){
		usersService.save(users);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    ////@RequiresPermissions("product:users:update")
    public R update(@RequestBody UserEntity users){
		usersService.updateById(users);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    ////@RequiresPermissions("product:users:delete")
    public R delete(@RequestBody Integer[] userIds){
		usersService.removeByIds(Arrays.asList(userIds));

        return R.ok();
    }

}
