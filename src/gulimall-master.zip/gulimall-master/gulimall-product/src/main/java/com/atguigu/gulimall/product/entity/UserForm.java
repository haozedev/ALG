package com.atguigu.gulimall.product.entity;

import lombok.Data;

/**
 * @author haoze
 * @create 2025/5/27 11:27
 * @description
 */
@Data
public class UserForm {
    private String username;
    private String password;
    private String captcha;
    private String uuid;
    private String mobile;
}
