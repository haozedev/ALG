package com.atguigu.gulimall.product.dao;

import com.atguigu.gulimall.product.entity.UserEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户表
 *
 * @author haoze
 * @email ${email}
 * @date 2025-05-27 09:35:21
 */
@Mapper
public interface UsersDao extends BaseMapper<UserEntity> {

}
