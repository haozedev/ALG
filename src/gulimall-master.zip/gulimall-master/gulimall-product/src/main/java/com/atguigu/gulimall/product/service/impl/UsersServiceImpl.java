package com.atguigu.gulimall.product.service.impl;

import com.atguigu.common.utils.PageUtils;
import com.atguigu.common.utils.Query;
import com.atguigu.gulimall.product.dao.UsersDao;
import com.atguigu.gulimall.product.entity.UserEntity;
import com.atguigu.gulimall.product.service.UsersService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.Map;


@Service("usersService")
public class UsersServiceImpl extends ServiceImpl<UsersDao, UserEntity> implements UsersService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<UserEntity> page = this.page(
                new Query<UserEntity>().getPage(params),
                new QueryWrapper<UserEntity>()
        );

        return new PageUtils(page);
    }

    @Override
    public boolean validate(String userName, String password) {
        UserEntity UserEntity =
                this.baseMapper.selectOne(new QueryWrapper<UserEntity>().eq("userName", userName).eq("password", password));
        if (UserEntity!=null){
            return true;
        }
        return false;
    }

    @Override
    public UserEntity queryByUserName(String username) {
        UserEntity userEntity = this.baseMapper.selectOne(new QueryWrapper<UserEntity>().eq("username", username));
        return userEntity;
    }

}
