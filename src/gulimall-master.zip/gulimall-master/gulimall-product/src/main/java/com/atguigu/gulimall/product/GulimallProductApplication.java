package com.atguigu.gulimall.product;

import com.alibaba.cloud.nacos.NacosDiscoveryAutoConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("com.atguigu.gulimall.product.dao")
//@EnableDiscoveryClient
@SpringBootApplication(exclude = {
        NacosDiscoveryAutoConfiguration.class    // 禁用 Nacos 服务相关
})
public class GulimallProductApplication {

    public static void main(String[] args) {

        SpringApplication.run(GulimallProductApplication.class, args);
    }

}
