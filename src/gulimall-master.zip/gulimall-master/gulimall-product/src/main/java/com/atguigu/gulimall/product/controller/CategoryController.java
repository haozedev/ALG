package com.atguigu.gulimall.product.controller;

import com.atguigu.common.utils.R;
import com.atguigu.gulimall.product.entity.CategoryEntity;
import com.atguigu.gulimall.product.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


/**
 * 商品三级分类
 *
 * @author haoze
 * @email ${email}
 * @date 2024-10-25 21:33:04
 */
@RestController
@RequestMapping("product/category")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    /**
     * 列表 : 查出所有分类，然后以树形结构组装展示
     */
    @RequestMapping("/list/tree")
    public R list() {
        List<CategoryEntity> entities = categoryService.listWithTree();

//        List<CategoryEntity> lev1Menus = new ArrayList<>();
//        for (CategoryEntity entity : entities) {
//            if (entity.getParentCid()==0){
//                lev1Menus.add(entity);
//            }
//        }
        List<CategoryEntity> lev1Menus = entities.stream().filter(categoryEntity ->
                categoryEntity.getParentCid() == 0
        ).map((menu) -> {
            menu.setChildren(getChildren(menu, entities));
            return menu;
        }).sorted((menu1, menu2) -> {
            return (menu1.getSort() == null ? 0 : menu1.getSort()) - (menu2.getSort() == null ? 0 : menu2.getSort());
        }).collect(Collectors.toList());


        return R.ok().put("data", lev1Menus);
    }

    /**
     *        递归返回三级分类树形结构
     * @param root
     * @param all
     * @return
     */
    private List<CategoryEntity> getChildren(CategoryEntity root, List<CategoryEntity> all) {
        List<CategoryEntity> children = new ArrayList<>();

        children = all.stream().filter(categoryEntity -> {
            return categoryEntity.getParentCid() == root.getCatId();
        }).map(categoryEntity -> {
            //递归找子菜单
            categoryEntity.setChildren(getChildren(categoryEntity, all));
            return categoryEntity;
        }).sorted((menu1, menu2) -> {
            return (menu1.getSort() == null ? 0 : menu1.getSort()) - (menu2.getSort() == null ? 0 : menu2.getSort());
        }).collect(Collectors.toList());

//        for (CategoryEntity categoryEntity : all) {
//            // 如果当前节点的 parentCid 等于 root 的 catId，则是 root 的子节点
//            if (categoryEntity.getParentCid() == root.getCatId()) {
//                // 递归找子菜单并设置为当前节点的子节点
//                categoryEntity.setChildren(getChildren(categoryEntity, all));
//                // 将当前节点加入 children 列表
//                children.add(categoryEntity);
//            }
//        }

        return children;
    }

    /**
     * 信息
     */
    @RequestMapping("/info/{catId}")
    ////@RequiresPermissions("product:category:info")
    public R info(@PathVariable("catId") Long catId) {
        CategoryEntity category = categoryService.getById(catId);

        return R.ok().put("data", category);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    ////@RequiresPermissions("product:category:save")
    public R save(@RequestBody CategoryEntity category) {
        categoryService.save(category);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update/sort")
    ////@RequiresPermissions("product:category:update")
    public R update(@RequestBody CategoryEntity [] categorys) {
        categoryService.updateBatchById(Arrays.asList(categorys));

        return R.ok();
    }


    /**
     * 修改
     */
    @RequestMapping("/update")
    ////@RequiresPermissions("product:category:update")
    public R update(@RequestBody CategoryEntity category) {
        categoryService.updateById(category);

        return R.ok();
    }

    /**
     * 删除
     * @RequestBody:获取请求体，必须发送POST请求
     * SpringMvc自动将请求体的数据JSON，转换为对象
     */
    @RequestMapping("/delete")
    ////@RequiresPermissions("product:category:delete")
    public R delete(@RequestBody Long[] catIds) {
        //categoryService.removeByIds(Arrays.asList(catIds));
        categoryService.removeMenusByIds(Arrays.asList(catIds));

        return R.ok();
    }

}
