package com.atguigu.gulimall.product.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户表
 *
 * @author haoze
 * @email ${email}
 * @date 2025-05-27 09:35:21
 */
@Data
@TableName("user")
public class UserEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 用户唯一标识
	 */
	@TableId
	private Integer userId;
	/**
	 * 用户名
	 */
	private String username;
	/**
	 * 用户密码（加密存储）
	 */
	private String password;
	/**
	 * 用户电话号码
	 */
	private String mobile;
	/**
	 * 盐
	 */
	private String salt;
	/**
	 * 用户创建时间
	 */
	private Date createTime;
	/**
	 * 用户信息更新时间
	 */
	private Date updateTime;

}
