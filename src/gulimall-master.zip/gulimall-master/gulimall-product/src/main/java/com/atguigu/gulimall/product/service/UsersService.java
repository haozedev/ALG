package com.atguigu.gulimall.product.service;

import com.atguigu.common.utils.PageUtils;
import com.atguigu.gulimall.product.entity.UserEntity;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * 用户表
 *
 * @author haoze
 * @email ${email}
 * @date 2025-05-27 09:35:21
 */
public interface UsersService extends IService<UserEntity> {

    PageUtils queryPage(Map<String, Object> params);

    boolean validate(String uuid, String captcha);

    UserEntity queryByUserName(String username);
}

