package com.atguigu.gulimall.product.dao;

import com.atguigu.gulimall.product.entity.AttrEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品属性
 * 
 * @author haoze
 * @email ${email}
 * @date 2024-10-25 21:33:04
 */
@Mapper
public interface AttrDao extends BaseMapper<AttrEntity> {
	
}
