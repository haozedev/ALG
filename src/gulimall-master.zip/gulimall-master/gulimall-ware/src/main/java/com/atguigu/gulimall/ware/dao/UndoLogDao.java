package com.atguigu.gulimall.ware.dao;

import com.atguigu.gulimall.ware.entity.UndoLogEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author haoze
 * @email ${email}
 * @date 2024-10-19 10:15:50
 */
@Mapper
public interface UndoLogDao extends BaseMapper<UndoLogEntity> {
	
}
